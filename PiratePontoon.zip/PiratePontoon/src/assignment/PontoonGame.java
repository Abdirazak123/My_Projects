package assignment;

public class PontoonGame {
	  public static void main(String[] args) {
	    // Create a new GameEngine instance
	    GameEngine game = new GameEngine();

	    // Start the game
	    game.play();
	  }
	}