/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Abdulahi
 */
public class EducationalInstitutes {
    private Integer id;
    private String edicationalInstitutesName;
    private String address;
    private String coursesOffered;
    private String coursesInformation;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    

    public String getEdicationalInstitutesName() {
        return edicationalInstitutesName;
    }

    public void setEdicationalInstitutesName(String edicationalInstitutesName) {
        this.edicationalInstitutesName = edicationalInstitutesName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCoursesOffered() {
        return coursesOffered;
    }

    public void setCoursesOffered(String coursesOffered) {
        this.coursesOffered = coursesOffered;
    }

    public String getCoursesInformation() {
        return coursesInformation;
    }

    public void setCoursesInformation(String coursesInformation) {
        this.coursesInformation = coursesInformation;
    }
    
    
}
