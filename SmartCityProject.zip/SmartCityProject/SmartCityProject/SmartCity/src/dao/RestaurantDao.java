/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;

import models.Restaurant;

/**
 *
 * @author Abdulahi
 */
public interface RestaurantDao {
    Boolean addRestaurant(Restaurant restaurant);
    List<Restaurant> getAllRestaurant();
    Boolean updateRestaurant(Restaurant restaurant);
    Boolean deleteRestaurant(Integer id);
    Restaurant getRestaurantById(Integer id);
}
