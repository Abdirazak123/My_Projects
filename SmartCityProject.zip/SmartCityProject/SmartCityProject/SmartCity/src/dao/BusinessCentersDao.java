/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import models.BusinessCenters;

/**
 *
 * @author Abdulahi
 */
public interface BusinessCentersDao {
    Boolean addBusinessCenters(BusinessCenters businessCenters);
    List<BusinessCenters> getAllBusinessCenters();
    Boolean updateBusinessCenters(BusinessCenters businessCenters);
    Boolean deleteBusinessCenters(Integer id);
    BusinessCenters getBusinessCentersById(Integer id);
}
