/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import models.JobOpportunities;

/**
 *
 * @author Abdulahi
 */
public interface JobOpportunitiesDao {
    Boolean addJobOpportunities(JobOpportunities jobOpportunities);
    List<JobOpportunities> getAllJobOpportunities();
    Boolean updateJobOpportunities(JobOpportunities jobOpportunities);
    Boolean deleteJobOpportunities(Integer id);
    JobOpportunities getJobOpportunitiesById(Integer id);
}
