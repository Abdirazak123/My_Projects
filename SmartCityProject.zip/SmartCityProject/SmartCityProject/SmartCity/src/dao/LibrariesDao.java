/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import models.Libraries;
import ui.LibrariesFrame;

/**
 *
 * @author Abdulahi
 */
public interface LibrariesDao {
    Boolean addLibraries(Libraries libraries);
    List<Libraries> getAllLibraries();
    Boolean updateLibraries(Libraries libraries);
    Boolean deleteLibraries(Integer id);
    Libraries getLibrariesById(Integer id);
}
