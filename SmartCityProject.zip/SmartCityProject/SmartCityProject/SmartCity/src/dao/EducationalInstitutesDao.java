/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import models.EducationalInstitutes;

/**
 *
 * @author Abdulahi
 */
public interface EducationalInstitutesDao {
     Boolean addEducationalInstitutes(EducationalInstitutes educationalInstitutes);
    List<EducationalInstitutes> getAllEducationalInstitutes();
    Boolean updateEducationalInstitutes(EducationalInstitutes educationalInstitutes);
    Boolean deleteEducationalInstitutesHotel(Integer id);
    EducationalInstitutes getEducationalInstitutesById(Integer id);
}
