/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.HotelDao;
import dbconnection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Hotel;

/**
 *
 * @author Abdulahi
 */
public class HotelDaoImpl implements HotelDao{
    
    Connection connection=DbConnection.getConnection();
    private static final String INSERT_HOTEL_QUERY = "insert into hotels(name,address,contact,price_range,facilities) values(?,?,?,?,?)";
    private static final String GET_ALL_HOTELS_QUERY ="select * from hotels";
    private static final String UPDATE_HOTEL_QUERY = "update hotels set name=?,address=?,contact=?,price_range=?,facilities=? where id=?";
    private static final String DELETE_HOTEL_QUERY = "delete from hotels where id=?;";
    private static final String  GET_HOTEL_BY_ID_QUERY="select * from hotels where id=?";
 

    @Override
    public Boolean addHotel(Hotel hotel) {
        boolean success=true;
        try{
            PreparedStatement ps=connection.prepareStatement(INSERT_HOTEL_QUERY);
            ps.setString(1,hotel.getName());
            ps.setString(2,hotel.getAddress());
            ps.setString(3,hotel.getContact());
            ps.setString(4,hotel.getPriceRange());
            ps.setString(5,hotel.getFacilities());
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return success;
    }

    @Override
    public List<Hotel> getAllHotel() {
     List<Hotel> getAllHotelsList=new ArrayList<>();
        try{
            PreparedStatement ps = connection.prepareStatement(GET_ALL_HOTELS_QUERY);
            ResultSet rst = ps.executeQuery();
            while(rst.next()){
                Hotel hotel=new Hotel();
                hotel.setId(rst.getInt("id"));
                hotel.setName(rst.getString("name"));
                hotel.setAddress(rst.getString("address"));
                hotel.setContact(rst.getString("contact"));
                hotel.setPriceRange(rst.getString("price_range"));
                hotel.setFacilities(rst.getString("facilities"));
                getAllHotelsList.add(hotel);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return getAllHotelsList;    
    }

    @Override
    public Boolean updateHotel(Hotel hotel) {
        Boolean success=true;
        try {

            PreparedStatement ps= connection.prepareStatement(UPDATE_HOTEL_QUERY);
            ps.setString(1,hotel.getName());
            ps.setString(2,hotel.getAddress());
            ps.setString(3,hotel.getContact());
            ps.setString(4,hotel.getPriceRange());
            ps.setString(5,hotel.getFacilities());
            ps.setInt(6,hotel.getId());
            ps.execute();

        } catch (Exception e) {
            success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public Boolean deleteHotel(Integer id) {
         Boolean success=true;
        try {
            PreparedStatement ps = connection.prepareStatement(DELETE_HOTEL_QUERY);
            ps.setInt(1, id);
            ps.execute();
        } catch (Exception e) {
             success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public Hotel getHotelById(Integer id) {
         try{
            PreparedStatement ps=connection.prepareStatement(GET_HOTEL_BY_ID_QUERY);
            ps.setInt(1,id);
            ResultSet rst=ps.executeQuery();
            while(rst.next()){
                Hotel hotel=new Hotel();
                hotel.setId(rst.getInt("id"));
                hotel.setName(rst.getString("name"));
                hotel.setAddress(rst.getString("address"));
                hotel.setContact(rst.getString("contact"));
                hotel.setPriceRange(rst.getString("price_range"));
                hotel.setFacilities(rst.getString("facilities"));
                return  hotel;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
}
