/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.TouristAttractionDao;
import dbconnection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import models.TouristAttraction;

/**
 *
 * @author Abdulahi
 */
public class TouristAttractionDaoImpl implements TouristAttractionDao{
    
    Connection connection=DbConnection.getConnection();
    private static final String INSERT_TOURISTATTRACTION_QUERY = "insert into tourist_attractions(name,description,location,opening_hours,ticket_price) values(?,?,?,?,?)";
    private static final String GET_ALL_TOURISTATTRACTION_QUERY ="select * from tourist_attractions";
    private static final String UPDATE_TOURISTATTRACTION_QUERY = "update tourist_attractions set name=?,description=?,location=?,opening_hours=?,ticket_price=? where id=?";
    private static final String DELETE_TOURISTATTRACTION_QUERY = "delete from tourist_attractions where id=?;";
    private static final String  GET_TOURISTATTRACTION_BY_ID_QUERY="select * from tourist_attractions where id=?";

    @Override
    public Boolean addTouristAttraction(TouristAttraction touristAttraction) {
        boolean success=true;
        try{
            PreparedStatement ps=connection.prepareStatement(INSERT_TOURISTATTRACTION_QUERY);
            ps.setString(1,touristAttraction.getName());
            ps.setString(2,touristAttraction.getDescription());
            ps.setString(3,touristAttraction.getLocation());
            ps.setString(4,touristAttraction.getOpeningHours());
            ps.setString(5,touristAttraction.getTicketPrice());
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return success;
    }

    @Override
    public List<TouristAttraction> getAllTouristAttraction() {
        List<TouristAttraction> getAllTouristAttractionList=new ArrayList<>();
        try{
            PreparedStatement ps = connection.prepareStatement(GET_ALL_TOURISTATTRACTION_QUERY);
            ResultSet rst = ps.executeQuery();
            while(rst.next()){
                TouristAttraction touristAttraction=new TouristAttraction();
                touristAttraction.setId(rst.getInt("id"));
                touristAttraction.setName(rst.getString("name"));
                touristAttraction.setLocation(rst.getString("location"));
                touristAttraction.setOpeningHours(rst.getString("opening_hours"));
                touristAttraction.setTicketPrice(rst.getString("ticket_price"));
                touristAttraction.setDescription(rst.getString("description"));
                getAllTouristAttractionList.add(touristAttraction);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return getAllTouristAttractionList;    
    }

    @Override
    public Boolean updateTouristAttraction(TouristAttraction touristAttraction) {
        Boolean success=true;
        try {
            PreparedStatement ps= connection.prepareStatement(UPDATE_TOURISTATTRACTION_QUERY);
            ps.setString(1,touristAttraction.getName());
            ps.setString(2,touristAttraction.getDescription());
            ps.setString(3,touristAttraction.getLocation());
            ps.setString(4,touristAttraction.getOpeningHours());
            ps.setString(5,touristAttraction.getTicketPrice());
            ps.setInt(6,touristAttraction.getId());
            ps.execute();

        } catch (Exception e) {
            success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public Boolean deleteTouristAttraction(Integer id) {
       Boolean success=true;
        try {
            PreparedStatement ps = connection.prepareStatement(DELETE_TOURISTATTRACTION_QUERY);
            ps.setInt(1, id);
            ps.execute();
        } catch (Exception e) {
             success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public TouristAttraction getTouristAttractionById(Integer id) {
        try{
            PreparedStatement ps=connection.prepareStatement(GET_TOURISTATTRACTION_BY_ID_QUERY);
            ps.setInt(1,id);
            ResultSet rst=ps.executeQuery();
            while(rst.next()){
                TouristAttraction touristAttraction=new TouristAttraction();
                touristAttraction.setId(rst.getInt("id"));
                touristAttraction.setName(rst.getString("name"));
                touristAttraction.setLocation(rst.getString("location"));
                touristAttraction.setOpeningHours(rst.getString("opening_hours"));
                touristAttraction.setTicketPrice(rst.getString("ticket_price"));
                touristAttraction.setDescription(rst.getString("description"));
             
                return  touristAttraction;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
}
