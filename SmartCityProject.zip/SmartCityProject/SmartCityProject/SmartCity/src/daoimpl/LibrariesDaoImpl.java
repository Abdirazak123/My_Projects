/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.LibrariesDao;
import dbconnection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Hotel;
import models.Libraries;
import ui.LibrariesFrame;

/**
 *
 * @author Abdulahi
 */
public class LibrariesDaoImpl implements LibrariesDao{
     
    Connection connection=DbConnection.getConnection();
    private static final String INSERT_LIBRARIES_QUERY = "insert into libraries(name,address,opening_hours,information) values(?,?,?,?)";
    private static final String GET_ALL_LIBRARIES_QUERY ="select * from libraries";
    private static final String UPDATE_LIBRARIES_QUERY = "update libraries set name=?,address=?,opening_hours=?,information=? where id=?";
    private static final String DELETE_LIBRARIES_QUERY = "delete from libraries where id=?;";
    private static final String  GET_LIBRARIES_BY_ID_QUERY="select * from libraries where id=?";

    @Override
    public Boolean addLibraries(Libraries libraries) {
       boolean success=true;
        try{
            PreparedStatement ps=connection.prepareStatement(INSERT_LIBRARIES_QUERY);
            ps.setString(1,libraries.getLibraryName());
            ps.setString(2,libraries.getAddress());
            ps.setString(3,libraries.getOpeningHours());
            ps.setString(4,libraries.getInformation());
            
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return success;
    }

    @Override
    public List<Libraries> getAllLibraries() {
         List<Libraries> getAlllibrariesList=new ArrayList<>();
        try{
            PreparedStatement ps = connection.prepareStatement(GET_ALL_LIBRARIES_QUERY);
            ResultSet rst = ps.executeQuery();
            while(rst.next()){
                Libraries libraries=new Libraries();
                libraries.setId(rst.getInt("id"));
                libraries.setLibraryName(rst.getString("name"));
                libraries.setAddress(rst.getString("address"));
                libraries.setOpeningHours(rst.getString("opening_hours"));
                libraries.setInformation(rst.getString("information"));
                getAlllibrariesList.add(libraries);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return getAlllibrariesList;    
    }

    @Override
    public Boolean updateLibraries(Libraries libraries) {
         Boolean success=true;
        try {

            PreparedStatement ps= connection.prepareStatement(UPDATE_LIBRARIES_QUERY);
            ps.setString(1,libraries.getLibraryName());
            ps.setString(2,libraries.getAddress());
            ps.setString(3,libraries.getOpeningHours());
            ps.setString(4,libraries.getInformation());
            ps.setInt(5,libraries.getId());
            ps.execute();

        } catch (Exception e) {
            success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public Boolean deleteLibraries(Integer id) {
        Boolean success=true;
        try {
            PreparedStatement ps = connection.prepareStatement(DELETE_LIBRARIES_QUERY);
            ps.setInt(1, id);
            ps.execute();
        } catch (Exception e) {
             success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public Libraries getLibrariesById(Integer id) {
       try{
            PreparedStatement ps=connection.prepareStatement(GET_LIBRARIES_BY_ID_QUERY);
            ps.setInt(1,id);
            ResultSet rst=ps.executeQuery();
            while(rst.next()){
                Libraries libraries=new Libraries();
                libraries.setId(rst.getInt("id"));
                libraries.setLibraryName(rst.getString("name"));
                libraries.setAddress(rst.getString("address"));
                libraries.setOpeningHours(rst.getString("opening_hours"));
                libraries.setInformation(rst.getString("information"));
                return  libraries;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

  
    
}
