/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.EducationalInstitutesDao;
import dbconnection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.EducationalInstitutes;

/**
 *
 * @author Abdulahi
 */
public class EducationalInstitutesDaoImpl implements EducationalInstitutesDao {
    Connection connection=DbConnection.getConnection();
    private static final String INSERT_EDUCATIONALINSTITUTES_QUERY = "insert into educational_institutes(name,address,courses_offered,contact) values(?,?,?,?)";
    private static final String GET_ALL_EDUCATIONALINSTITUTES_QUERY ="select * from educational_institutes";
    private static final String UPDATE_EDUCATIONALINSTITUTES_QUERY = "update educational_institutes set name=?,address=?,courses_offered=?,contact=? where id=?";
    private static final String DELETE_EDUCATIONALINSTITUTES_QUERY = "delete from educational_institutes where id=?;";
    private static final String  GET_EDUCATIONALINSTITUTES_BY_ID_QUERY="select * from educational_institutes where id=?";
 
    @Override
    public Boolean addEducationalInstitutes(EducationalInstitutes educationalInstitutes) {
        boolean success=true;
        try{
            PreparedStatement ps=connection.prepareStatement(INSERT_EDUCATIONALINSTITUTES_QUERY);
            ps.setString(1,educationalInstitutes.getEdicationalInstitutesName());
            ps.setString(2,educationalInstitutes.getAddress());
            ps.setString(3,educationalInstitutes.getCoursesOffered());
            ps.setString(4,educationalInstitutes.getCoursesInformation());
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return success;
    }

    @Override
    public List<EducationalInstitutes> getAllEducationalInstitutes() {
        List<EducationalInstitutes> getAllEducationalInstitutesList=new ArrayList<>();
        try{
            PreparedStatement ps = connection.prepareStatement(GET_ALL_EDUCATIONALINSTITUTES_QUERY);
            ResultSet rst = ps.executeQuery();
            while(rst.next()){
               EducationalInstitutes educationalInstitutes=new EducationalInstitutes();
                educationalInstitutes.setId(rst.getInt("id"));
                educationalInstitutes.setEdicationalInstitutesName(rst.getString("name"));
                educationalInstitutes.setAddress(rst.getString("address"));
                educationalInstitutes.setCoursesInformation(rst.getString("contact"));
                educationalInstitutes.setCoursesOffered(rst.getString("courses_offered"));
                getAllEducationalInstitutesList.add(educationalInstitutes);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return getAllEducationalInstitutesList;    
    }

    @Override
    public Boolean updateEducationalInstitutes(EducationalInstitutes educationalInstitutes) {
        Boolean success=true;
        try {

            PreparedStatement ps= connection.prepareStatement(UPDATE_EDUCATIONALINSTITUTES_QUERY);
            ps.setString(1,educationalInstitutes.getEdicationalInstitutesName());
            ps.setString(2,educationalInstitutes.getAddress());
            ps.setString(3,educationalInstitutes.getCoursesOffered());
            ps.setString(4,educationalInstitutes.getCoursesInformation());
            ps.setInt(5,educationalInstitutes.getId());
            ps.execute();

        } catch (Exception e) {
            success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public Boolean deleteEducationalInstitutesHotel(Integer id) {
         Boolean success=true;
        try {
            PreparedStatement ps = connection.prepareStatement(DELETE_EDUCATIONALINSTITUTES_QUERY);
            ps.setInt(1, id);
            ps.execute();
        } catch (Exception e) {
             success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public EducationalInstitutes getEducationalInstitutesById(Integer id) {
        try{
            PreparedStatement ps=connection.prepareStatement(GET_EDUCATIONALINSTITUTES_BY_ID_QUERY);
            ps.setInt(1,id);
            ResultSet rst=ps.executeQuery();
            while(rst.next()){
                EducationalInstitutes educationalInstitutes=new EducationalInstitutes();
                educationalInstitutes.setId(rst.getInt("id"));
                educationalInstitutes.setEdicationalInstitutesName(rst.getString("name"));
                educationalInstitutes.setAddress(rst.getString("address"));
                educationalInstitutes.setCoursesInformation(rst.getString("contact"));
                educationalInstitutes.setCoursesOffered(rst.getString("courses_offered"));
            
                return  educationalInstitutes;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
}
