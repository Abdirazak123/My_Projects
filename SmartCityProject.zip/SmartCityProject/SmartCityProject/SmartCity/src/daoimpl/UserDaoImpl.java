/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.UserDao;
import dbconnection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Roles;
import models.User;

/**
 *
 * @author Haseeb
 */
public class UserDaoImpl implements UserDao{
    
    Connection connection=DbConnection.getConnection();
    private static final String Insert_USER_Query = "insert into administration(username,password,role) values(?,?,?);";
     private static final String Get_All_USERS_Query ="select * from administration";
    @Override
    public boolean addUser(User user) {
        boolean success=true;
        try{
            PreparedStatement ps=connection.prepareStatement(Insert_USER_Query);
            ps.setString(1,user.getUserName());
            ps.setString(2,user.getPassword());
            ps.setObject(3,Roles.valueOf(user.getRole().toString()).ordinal()+1);
            ps.execute();

        }catch(Exception e){
            success=false;
            e.printStackTrace();
        }
    return success;
    }

    @Override
    public List<User> getAllUser() {
        List<User> getAllUsersList=new ArrayList<>();
        try{
            PreparedStatement ps = connection.prepareStatement(Get_All_USERS_Query);
            ResultSet rst = ps.executeQuery();
            while(rst.next()){
                User user=new User();
                user.setUserName(rst.getString("username"));
                user.setPassword(rst.getString("password"));
                user.setRole(Roles.valueOf(rst.getString("role")));
                getAllUsersList.add(user);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return getAllUsersList;
    }
   
}
