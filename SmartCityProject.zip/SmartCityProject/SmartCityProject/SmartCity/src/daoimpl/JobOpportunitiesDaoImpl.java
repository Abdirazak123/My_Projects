/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.JobOpportunitiesDao;
import dbconnection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Hotel;
import models.JobOpportunities;

/**
 *
 * @author Abdulahi
 */
public class JobOpportunitiesDaoImpl implements JobOpportunitiesDao{

    Connection connection=DbConnection.getConnection();
    private static final String INSERT_JobOpportunities_QUERY = "insert into job_opportunities(name,description,location,requirements,salary_range) values(?,?,?,?,?)";
    private static final String GET_ALL_JobOpportunities_QUERY ="select * from job_opportunities";
    private static final String UPDATE_JobOpportunities_QUERY = "update job_opportunities set name=?,description=?,location=?,requirements=?,salary_range=? where id=?";
    private static final String DELETE_JobOpportunities_QUERY = "delete from job_opportunities where id=?;";
    private static final String  GET_JobOpportunities_BY_ID_QUERY="select * from job_opportunities where id=?";
    
    
    @Override
    public Boolean addJobOpportunities(JobOpportunities jobOpportunities) {
         boolean success=true;
        try{
            PreparedStatement ps=connection.prepareStatement(INSERT_JobOpportunities_QUERY);
            ps.setString(1,jobOpportunities.getName());
            ps.setString(2,jobOpportunities.getDescription());
            ps.setString(3,jobOpportunities.getLocation());
            ps.setString(4,jobOpportunities.getRequirements());
            ps.setString(5,jobOpportunities.getSalarayRange());
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return success;
    }

    @Override
    public List<JobOpportunities> getAllJobOpportunities() {
     List<JobOpportunities> getAllJobOpportunitiesList=new ArrayList<>();
        try{
            PreparedStatement ps = connection.prepareStatement(GET_ALL_JobOpportunities_QUERY);
            ResultSet rst = ps.executeQuery();
            while(rst.next()){
                JobOpportunities jobOpportunities=new JobOpportunities();
                jobOpportunities.setId(rst.getInt("id"));
                jobOpportunities.setName(rst.getString("name"));
                jobOpportunities.setDescription(rst.getString("description"));
                jobOpportunities.setLocation(rst.getString("location"));
                jobOpportunities.setRequirements(rst.getString("requirements"));
                jobOpportunities.setSalarayRange(rst.getString("salary_range"));
                getAllJobOpportunitiesList.add(jobOpportunities);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return getAllJobOpportunitiesList;    
    }

    @Override
    public Boolean updateJobOpportunities(JobOpportunities jobOpportunities) {
         Boolean success=true;
        try {

            PreparedStatement ps= connection.prepareStatement(UPDATE_JobOpportunities_QUERY);
            ps.setString(1,jobOpportunities.getName());
            ps.setString(2,jobOpportunities.getDescription());
            ps.setString(3,jobOpportunities.getLocation());
            ps.setString(4,jobOpportunities.getRequirements());
            ps.setString(5,jobOpportunities.getSalarayRange());
            ps.setInt(6,jobOpportunities.getId());
            ps.execute();

        } catch (Exception e) {
            success=false;
            e.printStackTrace();
        }
        return success;}

    @Override
    public Boolean deleteJobOpportunities(Integer id) {
        Boolean success=true;
        try {
            PreparedStatement ps = connection.prepareStatement(DELETE_JobOpportunities_QUERY);
            ps.setInt(1, id);
            ps.execute();
        } catch (Exception e) {
             success=false;
            e.printStackTrace();
        }
        return success;}

    @Override
    public JobOpportunities getJobOpportunitiesById(Integer id) {
        try{
            PreparedStatement ps=connection.prepareStatement(GET_JobOpportunities_BY_ID_QUERY);
            ps.setInt(1,id);
            ResultSet rst=ps.executeQuery();
            while(rst.next()){
             JobOpportunities jobOpportunities=new JobOpportunities();
                jobOpportunities.setId(rst.getInt("id"));
                jobOpportunities.setName(rst.getString("name"));
                jobOpportunities.setDescription(rst.getString("description"));
                jobOpportunities.setLocation(rst.getString("location"));
                jobOpportunities.setRequirements(rst.getString("requirements"));
                jobOpportunities.setSalarayRange(rst.getString("salary_range"));
                return  jobOpportunities;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
}
