/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.BusinessCentersDao;
import dbconnection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.BusinessCenters;
import models.Hotel;

/**
 *
 * @author Abdulahi
 */
public class BusinessCentersDaoImpl implements BusinessCentersDao {
    
    Connection connection=DbConnection.getConnection();
    private static final String INSERT_BUSINESSCENTERS_QUERY = "insert into business_centers(name,address,facilities,contact) values(?,?,?,?)";
    private static final String GET_ALL_BUSINESSCENTERS_QUERY ="select * from business_centers";
    private static final String UPDATE_BUSINESSCENTERS_QUERY = "update business_centers set name=?,address=?,facilities=?,contact=? where id=?";
    private static final String DELETE_BUSINESSCENTERS_QUERY = "delete from business_centers where id=?;";
    private static final String  GET_BUSINESSCENTERS_BY_ID_QUERY="select * from business_centers where id=?";

    @Override
    public Boolean addBusinessCenters(BusinessCenters businessCenters) {
        boolean success=true;
        try{
            PreparedStatement ps=connection.prepareStatement(INSERT_BUSINESSCENTERS_QUERY);
            ps.setString(1,businessCenters.getName());
            ps.setString(2,businessCenters.getAddress());
            ps.setString(3,businessCenters.getFacilities());
            ps.setString(4,businessCenters.getContact());
           
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return success;
    }

    @Override
    public List<BusinessCenters> getAllBusinessCenters() {
       List<BusinessCenters> getAllBusinessCentersList=new ArrayList<>();
        try{
            PreparedStatement ps = connection.prepareStatement(GET_ALL_BUSINESSCENTERS_QUERY);
            ResultSet rst = ps.executeQuery();
            while(rst.next()){
                BusinessCenters businessCenters=new BusinessCenters();
                businessCenters.setId(rst.getInt("id"));
                businessCenters.setName(rst.getString("name"));
                businessCenters.setAddress(rst.getString("address"));
                businessCenters.setContact(rst.getString("contact"));
                businessCenters.setFacilities(rst.getString("facilities"));
                getAllBusinessCentersList.add(businessCenters);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return getAllBusinessCentersList;   
    }

    @Override
    public Boolean updateBusinessCenters(BusinessCenters businessCenters) {
        Boolean success=true;
        try {

            PreparedStatement ps= connection.prepareStatement(UPDATE_BUSINESSCENTERS_QUERY);
             ps.setString(1,businessCenters.getName());
            ps.setString(2,businessCenters.getAddress());
            ps.setString(3,businessCenters.getFacilities());
            ps.setString(4,businessCenters.getContact());
            ps.setInt(5,businessCenters.getId());
            ps.execute();

        } catch (Exception e) {
            success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public Boolean deleteBusinessCenters(Integer id) {
         Boolean success=true;
        try {
            PreparedStatement ps = connection.prepareStatement(DELETE_BUSINESSCENTERS_QUERY);
            ps.setInt(1, id);
            ps.execute();
        } catch (Exception e) {
             success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public BusinessCenters getBusinessCentersById(Integer id) {
        try{
            PreparedStatement ps=connection.prepareStatement(GET_BUSINESSCENTERS_BY_ID_QUERY);
            ps.setInt(1,id);
            ResultSet rst=ps.executeQuery();
            while(rst.next()){
                BusinessCenters businessCenters=new BusinessCenters();
                businessCenters.setId(rst.getInt("id"));
                businessCenters.setName(rst.getString("name"));
                businessCenters.setAddress(rst.getString("address"));
                businessCenters.setContact(rst.getString("contact"));
                businessCenters.setFacilities(rst.getString("facilities"));
                return  businessCenters;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
}
