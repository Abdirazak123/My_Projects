/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.NewsOpportunitiesDao;
import dbconnection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Hotel;
import models.NewsOpportunities;

/**
 *
 * @author Abdulahi
 */
public class NewsOpportunitiesDaoImpl implements NewsOpportunitiesDao{
    Connection connection=DbConnection.getConnection();
    private static final String INSERT_NEWSOPPORTUNITIES_QUERY = "insert into news_opportunities(name,headline,description) values(?,?,?)";
    private static final String GET_ALL_NEWSOPPORTUNITIES_QUERY ="select * from news_opportunities";
    private static final String UPDATE_NEWSOPPORTUNITIES_QUERY = "update news_opportunities set name=?,headline=?,description=? where id=?";
    private static final String DELETE_NEWSOPPORTUNITIES_QUERY = "delete from news_opportunities where id=?;";
    private static final String  GET_NEWSOPPORTUNITIES_BY_ID_QUERY="select * from news_opportunities where id=?";
  
    
    @Override
    public Boolean addNewsOpportunities(NewsOpportunities newsOpportunities) {
         boolean success=true;
        try{
            PreparedStatement ps=connection.prepareStatement(INSERT_NEWSOPPORTUNITIES_QUERY);
            ps.setString(1,newsOpportunities.getName());
            ps.setString(2,newsOpportunities.getHeadline());
            ps.setString(3,newsOpportunities.getDescription());
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return success;
    }

    @Override
    public List<NewsOpportunities> getAllNewsOpportunities() {
         List<NewsOpportunities> getAllNewsOpportunitiesList=new ArrayList<>();
        try{
            PreparedStatement ps = connection.prepareStatement(GET_ALL_NEWSOPPORTUNITIES_QUERY);
            ResultSet rst = ps.executeQuery();
            while(rst.next()){
               NewsOpportunities newsOpportunities=new NewsOpportunities();
                newsOpportunities.setId(rst.getInt("id"));
                newsOpportunities.setName(rst.getString("name"));
                newsOpportunities.setHeadline(rst.getString("headline"));
                newsOpportunities.setDescription(rst.getString("description"));
                getAllNewsOpportunitiesList.add(newsOpportunities);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return getAllNewsOpportunitiesList;    
    }

    @Override
    public Boolean updateNewsOpportunities(NewsOpportunities newsOpportunities) {
        Boolean success=true;
        try {

            PreparedStatement ps= connection.prepareStatement(UPDATE_NEWSOPPORTUNITIES_QUERY);
            ps.setString(1,newsOpportunities.getName());
            ps.setString(2,newsOpportunities.getHeadline());
            ps.setString(3,newsOpportunities.getDescription());
            ps.setInt(4,newsOpportunities.getId());
            ps.execute();

        } catch (Exception e) {
            success=false;
            e.printStackTrace();
        }
        return success;}

    @Override
    public Boolean deleteNewsOpportunities(Integer id) {
       Boolean success=true;
        try {
            PreparedStatement ps = connection.prepareStatement(DELETE_NEWSOPPORTUNITIES_QUERY);
            ps.setInt(1, id);
            ps.execute();
        } catch (Exception e) {
             success=false;
            e.printStackTrace();
        }
        return success; }

    @Override
    public NewsOpportunities getNewsOpportunitiesById(Integer id) {
        try{
            PreparedStatement ps=connection.prepareStatement(GET_NEWSOPPORTUNITIES_BY_ID_QUERY);
            ps.setInt(1,id);
            ResultSet rst=ps.executeQuery();
            while(rst.next()){
               NewsOpportunities newsOpportunities=new NewsOpportunities();
                newsOpportunities.setId(rst.getInt("id"));
                newsOpportunities.setName(rst.getString("name"));
                newsOpportunities.setHeadline(rst.getString("headline"));
                newsOpportunities.setDescription(rst.getString("description"));
                return  newsOpportunities;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;}
    
}
