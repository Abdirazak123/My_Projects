/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoimpl;

import dao.RestaurantDao;
import dbconnection.DbConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Restaurant;

/**
 *
 * @author Abdulahi
 */
public class RestaurantDaoImpl implements RestaurantDao{

    
    Connection connection=DbConnection.getConnection();
    private static final String INSERT_RESTAURANT_QUERY = "insert into restaurants(name,address,cuisine,avg_cost,opening_hours) values(?,?,?,?,?)";
    private static final String GET_ALL_RESTAURANT_QUERY ="select * from restaurants";
    private static final String UPDATE_RESTAURANT_QUERY = "update restaurants set name=?,address=?,cuisine=?,avg_cost=?,opening_hours=? where id=?";
    private static final String DELETE_RESTAURANT_QUERY = "delete from restaurants where id=?;";
    private static final String  GET_RESTAURANT_BY_ID_QUERY="select * from restaurants where id=?";
 
    
    @Override
    public Boolean addRestaurant(Restaurant restaurant) {
           boolean success=true;
        try{
            PreparedStatement ps=connection.prepareStatement(INSERT_RESTAURANT_QUERY);
            ps.setString(1,restaurant.getName());
            ps.setString(2,restaurant.getAddress());
            ps.setString(3,restaurant.getCuisine());
            ps.setString(4,restaurant.getAverageCost());
            ps.setString(5,restaurant.getOpeningHours());
            ps.execute();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return success;    
    }

    @Override
    public List<Restaurant> getAllRestaurant() {
         List<Restaurant> getAllRestaurantsList=new ArrayList<>();
        try{
            PreparedStatement ps = connection.prepareStatement(GET_ALL_RESTAURANT_QUERY);
            ResultSet rst = ps.executeQuery();
            while(rst.next()){
                Restaurant restaurant=new Restaurant();
                restaurant.setId(rst.getInt("id"));
                restaurant.setName(rst.getString("name"));
                restaurant.setAddress(rst.getString("address"));
                restaurant.setCuisine(rst.getString("cuisine"));
                restaurant.setAverageCost(rst.getString("avg_cost"));
                restaurant.setOpeningHours(rst.getString("opening_hours"));
                getAllRestaurantsList.add(restaurant);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return getAllRestaurantsList;   
    }

    @Override
    public Boolean updateRestaurant(Restaurant restaurant) {
        Boolean success=true;
        try {

            PreparedStatement ps= connection.prepareStatement(UPDATE_RESTAURANT_QUERY);
            ps.setString(1,restaurant.getName());
            ps.setString(2,restaurant.getAddress());
            ps.setString(3,restaurant.getCuisine());
            ps.setString(4,restaurant.getAverageCost());
            ps.setString(5,restaurant.getOpeningHours());
            ps.setInt(6,restaurant.getId());
            ps.execute();

        } catch (Exception e) {
            success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public Boolean deleteRestaurant(Integer id) {
         Boolean success=true;
        try {
            PreparedStatement ps = connection.prepareStatement(DELETE_RESTAURANT_QUERY);
            ps.setInt(1, id);
            ps.execute();
        } catch (Exception e) {
             success=false;
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public Restaurant getRestaurantById(Integer id) {
         try{
            PreparedStatement ps=connection.prepareStatement(GET_RESTAURANT_BY_ID_QUERY);
            ps.setInt(1,id);
            ResultSet rst=ps.executeQuery();
            while(rst.next()){
                Restaurant restaurant=new Restaurant();
                restaurant.setId(rst.getInt("id"));
                restaurant.setName(rst.getString("name"));
                restaurant.setAddress(rst.getString("address"));
                restaurant.setCuisine(rst.getString("cuisine"));
                restaurant.setAverageCost(rst.getString("avg_cost"));
                restaurant.setOpeningHours(rst.getString("opening_hours"));
                return  restaurant;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
}
