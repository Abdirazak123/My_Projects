package parallel;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.*;

public class GameOfLifeP extends JPanel {
    private int gridWidth = 50;
    private int gridHeight = 50;
    private int cellSize = 10;
    private Cell[][] grid;

    public GameOfLifeP() {
        grid = new Cell[gridHeight][gridWidth];
        for (int y = 0; y < gridHeight; y++) {
            for (int x = 0; x < gridWidth; x++) {
                grid[y][x] = new Cell(Math.random() < 0.5);
            }
        }

        new Timer(1000, e -> {
            update();
            repaint();
        }).start();
    }

    public void randomize() {
        for (int y = 0; y < gridHeight; y++) {
            for (int x = 0; x < gridWidth; x++) {
                grid[y][x].setAlive(Math.random() < 0.5);
            }
        }
    }

    public void update() {
        ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        for (int y = 0; y < gridHeight; y++) {
            int finalY = y;
            executor.execute(() -> {
                for (int x = 0; x < gridWidth; x++) {
                    int aliveNeighbors = countLiveNeighbors(x, finalY);
                    if (grid[finalY][x].isAlive()) {
                        grid[finalY][x].setAlive(aliveNeighbors == 2 || aliveNeighbors == 3);
                    } else {
                        grid[finalY][x].setAlive(aliveNeighbors == 3);
                    }
                }
            });
        }
        executor.shutdown();
        try {
            executor.awaitTermination(1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public int countLiveNeighbors(int x, int y) {
        int count = 0;
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                if (dx == 0 && dy == 0) continue;
                int ny = y + dy;
                int nx = x + dx;
                if (ny >= 0 && ny < gridHeight && nx >= 0 && nx < gridWidth && grid[ny][nx].isAlive()) {
                    count++;
                }
            }
        }
        return count;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (int y = 0; y < gridHeight; y++) {
            for (int x = 0; x < gridWidth; x++) {
                g.setColor(grid[y][x].isAlive() ? Color.BLACK : Color.WHITE);
                g.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
                g.setColor(Color.BLACK);
                g.drawRect(x * cellSize, y * cellSize, cellSize, cellSize);
            }
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Game of Life Parallel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new GameOfLifeP());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setSize(500, 500); // Set the width and height here
        frame.setVisible(true);
    }
}


