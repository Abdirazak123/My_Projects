/**
 * 
 */
/**
 * 
 */
module PProject {
	requires java.desktop;
}