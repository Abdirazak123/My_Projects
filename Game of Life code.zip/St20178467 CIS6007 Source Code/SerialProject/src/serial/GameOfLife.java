package serial;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameOfLife extends JPanel {
    private int gridWidth = 50;
    private int gridHeight = 50;
    private int cellSize = 10;
    private int[][] grid;

    public GameOfLife() {
        grid = new int[gridHeight][gridWidth];
        randomize();

        setPreferredSize(new Dimension(gridWidth * cellSize, gridHeight * cellSize));
        setBackground(Color.WHITE);

        new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                update();
                repaint();
            }
        }).start();
    }

    public void randomize() {
        for (int y = 0; y < gridHeight; y++) {
            for (int x = 0; x < gridWidth; x++) {
                grid[y][x] = (int) (Math.random() * 2);
            }
        }
    }

    public void update() {
        int[][] newGrid = new int[gridHeight][gridWidth];
        for (int y = 0; y < gridHeight; y++) {
            for (int x = 0; x < gridWidth; x++) {
                int neighbors = countNeighbors(x, y);
                if (grid[y][x] == 1) {
                    newGrid[y][x] = (neighbors == 2 || neighbors == 3) ? 1 : 0;
                } else {
                    newGrid[y][x] = (neighbors == 3) ? 1 : 0;
                }
            }
        }
        grid = newGrid;
    }

    public int countNeighbors(int x, int y) {
        int count = 0;
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                if (dx == 0 && dy == 0) continue;
                int ny = y + dy;
                int nx = x + dx;
                if (ny >= 0 && ny < gridHeight && nx >= 0 && nx < gridWidth && grid[ny][nx] == 1) {
                    count++;
                }
            }
        }
        return count;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (int y = 0; y < gridHeight; y++) {
            for (int x = 0; x < gridWidth; x++) {
                g.setColor(grid[y][x] == 1 ? Color.BLACK : Color.WHITE);
                g.fillRect(x * cellSize, y * cellSize, cellSize, cellSize);
                g.setColor(Color.BLACK);
                g.drawRect(x * cellSize, y * cellSize, cellSize, cellSize);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame();
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setTitle("Game of Life Serial");
                frame.setResizable(false);
                frame.add(new GameOfLife(), BorderLayout.CENTER);
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });
    }
}