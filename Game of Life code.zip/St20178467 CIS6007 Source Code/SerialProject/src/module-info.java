/**
 * 
 */
/**
 * 
 */
module SerialProject {
	requires java.desktop;
}